import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function ProfileSetup() {
  const [selectedRole, setSelectedRole] = useState<"admin" | "faculty" | "student" | null>(null);
  const [facultyData, setFacultyData] = useState({
    fullName: "",
    department: "",
    position: "",
  });

  const createUserProfile = useMutation(api.users.createUserProfile);
  const createFacultyProfile = useMutation(api.faculty.createFacultyProfile);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRole) {
      toast.error("Please select a role");
      return;
    }

    try {
      await createUserProfile({ role: selectedRole });
      
      if (selectedRole === "faculty") {
        if (!facultyData.fullName || !facultyData.department || !facultyData.position) {
          toast.error("Please fill in all faculty information");
          return;
        }
        await createFacultyProfile(facultyData);
      }

      toast.success("Profile created successfully!");
    } catch (error) {
      toast.error("Failed to create profile");
      console.error(error);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-[600px] p-8">
      <div className="w-full max-w-2xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-primary mb-2">Complete Your Profile</h2>
            <p className="text-gray-600">Please select your role and provide additional information</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-4">Select Your Role</label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div
                  className={`border-2 rounded-lg p-6 cursor-pointer text-center transition-all ${
                    selectedRole === "admin"
                      ? "border-blue-500 bg-blue-50"
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                  onClick={() => setSelectedRole("admin")}
                >
                  <div className="text-3xl mb-2">👨‍💼</div>
                  <h3 className="font-semibold">Administrator</h3>
                  <p className="text-sm text-gray-600">System administrator</p>
                </div>

                <div
                  className={`border-2 rounded-lg p-6 cursor-pointer text-center transition-all ${
                    selectedRole === "faculty"
                      ? "border-blue-500 bg-blue-50"
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                  onClick={() => setSelectedRole("faculty")}
                >
                  <div className="text-3xl mb-2">👨‍🏫</div>
                  <h3 className="font-semibold">Faculty</h3>
                  <p className="text-sm text-gray-600">Teacher or staff member</p>
                </div>

                <div
                  className={`border-2 rounded-lg p-6 cursor-pointer text-center transition-all ${
                    selectedRole === "student"
                      ? "border-blue-500 bg-blue-50"
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                  onClick={() => setSelectedRole("student")}
                >
                  <div className="text-3xl mb-2">👨‍🎓</div>
                  <h3 className="font-semibold">Student</h3>
                  <p className="text-sm text-gray-600">Student or learner</p>
                </div>
              </div>
            </div>

            {selectedRole === "faculty" && (
              <div className="bg-blue-50 p-6 rounded-lg">
                <h4 className="font-semibold mb-4">Faculty Information</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={facultyData.fullName}
                      onChange={(e) => setFacultyData({ ...facultyData, fullName: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={facultyData.department}
                      onChange={(e) => setFacultyData({ ...facultyData, department: e.target.value })}
                      required
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Position</label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={facultyData.position}
                      onChange={(e) => setFacultyData({ ...facultyData, position: e.target.value })}
                      required
                    />
                  </div>
                </div>
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-3 px-4 rounded-md hover:bg-blue-700 transition-colors font-semibold"
              disabled={!selectedRole}
            >
              Complete Profile Setup
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
