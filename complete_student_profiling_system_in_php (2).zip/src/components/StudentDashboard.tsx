import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState } from "react";
import { toast } from "sonner";

export function StudentDashboard() {
  const studentProfile = useQuery(api.students.getStudentProfile);
  const createStudentProfile = useMutation(api.students.createStudentProfile);
  const updateStudentProfile = useMutation(api.students.updateStudentProfile);
  
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    fullName: "",
    dateOfBirth: "",
    placeOfBirth: "",
    homeAddress: "",
    citizenship: "",
    primaryLanguage: "",
    raceEthnicity: "",
    parentGuardianName: "",
    parentPhone: "",
    parentEmail: "",
    emergencyContact1Name: "",
    emergencyContact1Phone: "",
    emergencyContact2Name: "",
    emergencyContact2Phone: "",
    authorizedPickup: "",
    immunizationRecords: "",
    allergies: "",
    chronicConditions: "",
    medicationConsent: false,
    healthInsuranceProvider: "",
    healthInsurancePolicy: "",
  });

  // Initialize form data when profile loads
  useState(() => {
    if (studentProfile) {
      setFormData({
        fullName: studentProfile.fullName || "",
        dateOfBirth: studentProfile.dateOfBirth || "",
        placeOfBirth: studentProfile.placeOfBirth || "",
        homeAddress: studentProfile.homeAddress || "",
        citizenship: studentProfile.citizenship || "",
        primaryLanguage: studentProfile.primaryLanguage || "",
        raceEthnicity: studentProfile.raceEthnicity || "",
        parentGuardianName: studentProfile.parentGuardianName || "",
        parentPhone: studentProfile.parentPhone || "",
        parentEmail: studentProfile.parentEmail || "",
        emergencyContact1Name: studentProfile.emergencyContact1Name || "",
        emergencyContact1Phone: studentProfile.emergencyContact1Phone || "",
        emergencyContact2Name: studentProfile.emergencyContact2Name || "",
        emergencyContact2Phone: studentProfile.emergencyContact2Phone || "",
        authorizedPickup: studentProfile.authorizedPickup || "",
        immunizationRecords: studentProfile.immunizationRecords || "",
        allergies: studentProfile.allergies || "",
        chronicConditions: studentProfile.chronicConditions || "",
        medicationConsent: studentProfile.medicationConsent || false,
        healthInsuranceProvider: studentProfile.healthInsuranceProvider || "",
        healthInsurancePolicy: studentProfile.healthInsurancePolicy || "",
      });
    }
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (studentProfile) {
        await updateStudentProfile(formData);
        toast.success("Profile updated successfully!");
      } else {
        await createStudentProfile(formData);
        toast.success("Profile created successfully!");
      }
      setIsEditing(false);
    } catch (error) {
      toast.error("Failed to save profile");
      console.error(error);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  if (studentProfile === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Student Profile</h1>
            <p className="text-gray-600">
              {studentProfile ? "Manage your student information" : "Complete your student profile"}
            </p>
          </div>
          {studentProfile && !isEditing && (
            <button
              onClick={() => setIsEditing(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors"
            >
              Edit Profile
            </button>
          )}
        </div>
      </div>

      {!studentProfile || isEditing ? (
        <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Basic Information */}
            <div className="md:col-span-2">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Basic Information</h3>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
              <input
                type="text"
                name="fullName"
                value={formData.fullName}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date of Birth *</label>
              <input
                type="date"
                name="dateOfBirth"
                value={formData.dateOfBirth}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Place of Birth *</label>
              <input
                type="text"
                name="placeOfBirth"
                value={formData.placeOfBirth}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Citizenship *</label>
              <input
                type="text"
                name="citizenship"
                value={formData.citizenship}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Home Address *</label>
              <textarea
                name="homeAddress"
                value={formData.homeAddress}
                onChange={handleInputChange}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Primary Language *</label>
              <input
                type="text"
                name="primaryLanguage"
                value={formData.primaryLanguage}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Race/Ethnicity</label>
              <input
                type="text"
                name="raceEthnicity"
                value={formData.raceEthnicity}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Contact Information */}
            <div className="md:col-span-2 mt-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact Information</h3>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Parent/Guardian Name *</label>
              <input
                type="text"
                name="parentGuardianName"
                value={formData.parentGuardianName}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Parent Phone *</label>
              <input
                type="tel"
                name="parentPhone"
                value={formData.parentPhone}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Parent Email *</label>
              <input
                type="email"
                name="parentEmail"
                value={formData.parentEmail}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Emergency Contact 1 Name *</label>
              <input
                type="text"
                name="emergencyContact1Name"
                value={formData.emergencyContact1Name}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Emergency Contact 1 Phone *</label>
              <input
                type="tel"
                name="emergencyContact1Phone"
                value={formData.emergencyContact1Phone}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Emergency Contact 2 Name *</label>
              <input
                type="text"
                name="emergencyContact2Name"
                value={formData.emergencyContact2Name}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Emergency Contact 2 Phone *</label>
              <input
                type="tel"
                name="emergencyContact2Phone"
                value={formData.emergencyContact2Phone}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            {/* Health Information */}
            <div className="md:col-span-2 mt-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Health Information</h3>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Allergies</label>
              <textarea
                name="allergies"
                value={formData.allergies}
                onChange={handleInputChange}
                rows={2}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="List any known allergies"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Chronic Conditions</label>
              <textarea
                name="chronicConditions"
                value={formData.chronicConditions}
                onChange={handleInputChange}
                rows={2}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="List any chronic medical conditions"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Health Insurance Provider</label>
              <input
                type="text"
                name="healthInsuranceProvider"
                value={formData.healthInsuranceProvider}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Health Insurance Policy</label>
              <input
                type="text"
                name="healthInsurancePolicy"
                value={formData.healthInsurancePolicy}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="md:col-span-2">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  name="medicationConsent"
                  checked={formData.medicationConsent}
                  onChange={handleInputChange}
                  className="mr-2"
                />
                <span className="text-sm text-gray-700">I consent to medication administration if needed</span>
              </label>
            </div>
          </div>

          <div className="flex justify-end space-x-4 mt-8">
            {isEditing && (
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition-colors"
            >
              {studentProfile ? "Update Profile" : "Create Profile"}
            </button>
          </div>
        </form>
      ) : (
        <div className="bg-white rounded-lg shadow p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Basic Information Display */}
            <div className="md:col-span-2">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Basic Information</h3>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700">Full Name</label>
              <p className="text-sm text-gray-900">{studentProfile.fullName}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Date of Birth</label>
              <p className="text-sm text-gray-900">{studentProfile.dateOfBirth}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Place of Birth</label>
              <p className="text-sm text-gray-900">{studentProfile.placeOfBirth}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Citizenship</label>
              <p className="text-sm text-gray-900">{studentProfile.citizenship}</p>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700">Home Address</label>
              <p className="text-sm text-gray-900">{studentProfile.homeAddress}</p>
            </div>

            {/* Contact Information Display */}
            <div className="md:col-span-2 mt-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact Information</h3>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Parent/Guardian</label>
              <p className="text-sm text-gray-900">{studentProfile.parentGuardianName}</p>
              <p className="text-sm text-gray-500">{studentProfile.parentPhone}</p>
              <p className="text-sm text-gray-500">{studentProfile.parentEmail}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Emergency Contacts</label>
              <p className="text-sm text-gray-900">{studentProfile.emergencyContact1Name} - {studentProfile.emergencyContact1Phone}</p>
              <p className="text-sm text-gray-900">{studentProfile.emergencyContact2Name} - {studentProfile.emergencyContact2Phone}</p>
            </div>

            {/* Health Information Display */}
            <div className="md:col-span-2 mt-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Health Information</h3>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Allergies</label>
              <p className="text-sm text-gray-900">{studentProfile.allergies || "None reported"}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Chronic Conditions</label>
              <p className="text-sm text-gray-900">{studentProfile.chronicConditions || "None reported"}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Medication Consent</label>
              <p className="text-sm text-gray-900">{studentProfile.medicationConsent ? "Yes" : "No"}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Health Insurance</label>
              <p className="text-sm text-gray-900">{studentProfile.healthInsuranceProvider || "Not provided"}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
