import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // Students table for detailed information
  students: defineTable({
    userId: v.id("users"),
    // Basic Biographical & Demographic Data
    fullName: v.string(),
    dateOfBirth: v.string(),
    placeOfBirth: v.string(),
    homeAddress: v.string(),
    citizenship: v.string(),
    primaryLanguage: v.string(),
    raceEthnicity: v.optional(v.string()),
    
    // Contact & Emergency Information
    parentGuardianName: v.string(),
    parentPhone: v.string(),
    parentEmail: v.string(),
    emergencyContact1Name: v.string(),
    emergencyContact1Phone: v.string(),
    emergencyContact2Name: v.string(),
    emergencyContact2Phone: v.string(),
    authorizedPickup: v.optional(v.string()),
    
    // Medical & Health Records
    immunizationRecords: v.optional(v.string()),
    allergies: v.optional(v.string()),
    chronicConditions: v.optional(v.string()),
    medicationConsent: v.boolean(),
    healthInsuranceProvider: v.optional(v.string()),
    healthInsurancePolicy: v.optional(v.string()),
  })
    .index("by_user", ["userId"])
    .index("by_name", ["fullName"]),

  // Faculty table
  faculty: defineTable({
    userId: v.id("users"),
    fullName: v.string(),
    department: v.string(),
    position: v.string(),
  })
    .index("by_user", ["userId"])
    .index("by_department", ["department"]),

  // User profiles to extend auth users
  userProfiles: defineTable({
    userId: v.id("users"),
    role: v.union(v.literal("admin"), v.literal("faculty"), v.literal("student")),
    isActive: v.boolean(),
  })
    .index("by_user", ["userId"])
    .index("by_role", ["role"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
