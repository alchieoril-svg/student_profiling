import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Create student profile
export const createStudentProfile = mutation({
  args: {
    fullName: v.string(),
    dateOfBirth: v.string(),
    placeOfBirth: v.string(),
    homeAddress: v.string(),
    citizenship: v.string(),
    primaryLanguage: v.string(),
    raceEthnicity: v.optional(v.string()),
    parentGuardianName: v.string(),
    parentPhone: v.string(),
    parentEmail: v.string(),
    emergencyContact1Name: v.string(),
    emergencyContact1Phone: v.string(),
    emergencyContact2Name: v.string(),
    emergencyContact2Phone: v.string(),
    authorizedPickup: v.optional(v.string()),
    immunizationRecords: v.optional(v.string()),
    allergies: v.optional(v.string()),
    chronicConditions: v.optional(v.string()),
    medicationConsent: v.boolean(),
    healthInsuranceProvider: v.optional(v.string()),
    healthInsurancePolicy: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Check if student profile already exists
    const existingStudent = await ctx.db
      .query("students")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (existingStudent) {
      throw new Error("Student profile already exists");
    }

    return await ctx.db.insert("students", {
      userId,
      ...args,
    });
  },
});

// Get student profile
export const getStudentProfile = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    return await ctx.db
      .query("students")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();
  },
});

// Update student profile
export const updateStudentProfile = mutation({
  args: {
    fullName: v.string(),
    dateOfBirth: v.string(),
    placeOfBirth: v.string(),
    homeAddress: v.string(),
    citizenship: v.string(),
    primaryLanguage: v.string(),
    raceEthnicity: v.optional(v.string()),
    parentGuardianName: v.string(),
    parentPhone: v.string(),
    parentEmail: v.string(),
    emergencyContact1Name: v.string(),
    emergencyContact1Phone: v.string(),
    emergencyContact2Name: v.string(),
    emergencyContact2Phone: v.string(),
    authorizedPickup: v.optional(v.string()),
    immunizationRecords: v.optional(v.string()),
    allergies: v.optional(v.string()),
    chronicConditions: v.optional(v.string()),
    medicationConsent: v.boolean(),
    healthInsuranceProvider: v.optional(v.string()),
    healthInsurancePolicy: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const student = await ctx.db
      .query("students")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!student) {
      throw new Error("Student profile not found");
    }

    return await ctx.db.patch(student._id, args);
  },
});

// Get all students (admin and faculty only)
export const getAllStudents = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const currentUserProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!currentUserProfile || (currentUserProfile.role !== "admin" && currentUserProfile.role !== "faculty")) {
      throw new Error("Admin or Faculty access required");
    }

    return await ctx.db.query("students").collect();
  },
});

// Get student by ID (admin and faculty only)
export const getStudentById = query({
  args: { studentId: v.id("students") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const currentUserProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!currentUserProfile || (currentUserProfile.role !== "admin" && currentUserProfile.role !== "faculty")) {
      throw new Error("Admin or Faculty access required");
    }

    return await ctx.db.get(args.studentId);
  },
});
