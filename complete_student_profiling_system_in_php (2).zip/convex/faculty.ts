import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Create faculty profile
export const createFacultyProfile = mutation({
  args: {
    fullName: v.string(),
    department: v.string(),
    position: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Check if faculty profile already exists
    const existingFaculty = await ctx.db
      .query("faculty")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (existingFaculty) {
      throw new Error("Faculty profile already exists");
    }

    return await ctx.db.insert("faculty", {
      userId,
      fullName: args.fullName,
      department: args.department,
      position: args.position,
    });
  },
});

// Get faculty profile
export const getFacultyProfile = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    return await ctx.db
      .query("faculty")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();
  },
});

// Update faculty profile
export const updateFacultyProfile = mutation({
  args: {
    fullName: v.string(),
    department: v.string(),
    position: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const faculty = await ctx.db
      .query("faculty")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!faculty) {
      throw new Error("Faculty profile not found");
    }

    return await ctx.db.patch(faculty._id, {
      fullName: args.fullName,
      department: args.department,
      position: args.position,
    });
  },
});

// Get all faculty (admin only)
export const getAllFaculty = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const currentUserProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!currentUserProfile || currentUserProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    return await ctx.db.query("faculty").collect();
  },
});
