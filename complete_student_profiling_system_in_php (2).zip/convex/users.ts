import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Get current logged in user with profile
export const getCurrentUser = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const user = await ctx.db.get(userId);
    if (!user) return null;

    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    return { ...user, profile };
  },
});

// Create user profile after registration
export const createUserProfile = mutation({
  args: {
    role: v.union(v.literal("admin"), v.literal("faculty"), v.literal("student")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Check if profile already exists
    const existingProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (existingProfile) {
      throw new Error("Profile already exists");
    }

    return await ctx.db.insert("userProfiles", {
      userId,
      role: args.role,
      isActive: true,
    });
  },
});

// Get all users (admin only)
export const getAllUsers = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const currentUserProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!currentUserProfile || currentUserProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    const profiles = await ctx.db.query("userProfiles").collect();
    const users = [];

    for (const profile of profiles) {
      const user = await ctx.db.get(profile.userId);
      if (!user) continue;

      let additionalInfo = null;
      if (profile.role === "faculty") {
        additionalInfo = await ctx.db
          .query("faculty")
          .withIndex("by_user", (q) => q.eq("userId", profile.userId))
          .unique();
      } else if (profile.role === "student") {
        additionalInfo = await ctx.db
          .query("students")
          .withIndex("by_user", (q) => q.eq("userId", profile.userId))
          .unique();
      }

      users.push({
        ...user,
        profile,
        additionalInfo,
      });
    }

    return users;
  },
});

// Delete user (admin only)
export const deleteUser = mutation({
  args: { targetUserId: v.id("users") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const currentUserProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!currentUserProfile || currentUserProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    // Delete related records
    const targetProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", args.targetUserId))
      .unique();

    if (targetProfile) {
      if (targetProfile.role === "faculty") {
        const faculty = await ctx.db
          .query("faculty")
          .withIndex("by_user", (q) => q.eq("userId", args.targetUserId))
          .unique();
        if (faculty) await ctx.db.delete(faculty._id);
      } else if (targetProfile.role === "student") {
        const student = await ctx.db
          .query("students")
          .withIndex("by_user", (q) => q.eq("userId", args.targetUserId))
          .unique();
        if (student) await ctx.db.delete(student._id);
      }
      await ctx.db.delete(targetProfile._id);
    }

    // Note: We can't delete the auth user directly, but we can mark as inactive
    // The auth system handles user deletion
  },
});

// Get user statistics
export const getUserStats = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const currentUserProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!currentUserProfile || currentUserProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    const allProfiles = await ctx.db.query("userProfiles").collect();
    
    const stats = {
      totalUsers: allProfiles.length,
      totalFaculty: allProfiles.filter(p => p.role === "faculty").length,
      totalStudents: allProfiles.filter(p => p.role === "student").length,
      totalAdmins: allProfiles.filter(p => p.role === "admin").length,
    };

    return stats;
  },
});
