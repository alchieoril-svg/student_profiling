-- Database structure for Student Profiling System
CREATE DATABASE student_profiling;
USE student_profiling;

-- Users table for authentication
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'faculty', 'student') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Students table for detailed information
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    -- Basic Biographical & Demographic Data
    full_name VARCHAR(255) NOT NULL,
    date_of_birth DATE NOT NULL,
    place_of_birth VARCHAR(255) NOT NULL,
    home_address TEXT NOT NULL,
    citizenship VARCHAR(100) NOT NULL,
    primary_language VARCHAR(100) NOT NULL,
    race_ethnicity VARCHAR(100),
    
    -- Contact & Emergency Information
    parent_guardian_name VARCHAR(255) NOT NULL,
    parent_phone VARCHAR(20) NOT NULL,
    parent_email VARCHAR(255) NOT NULL,
    emergency_contact_1_name VARCHAR(255) NOT NULL,
    emergency_contact_1_phone VARCHAR(20) NOT NULL,
    emergency_contact_2_name VARCHAR(255) NOT NULL,
    emergency_contact_2_phone VARCHAR(20) NOT NULL,
    authorized_pickup TEXT,
    
    -- Medical & Health Records
    immunization_records TEXT,
    allergies TEXT,
    chronic_conditions TEXT,
    medication_consent BOOLEAN DEFAULT FALSE,
    health_insurance_provider VARCHAR(255),
    health_insurance_policy VARCHAR(255),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Faculty table
CREATE TABLE faculty (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    full_name VARCHAR(255) NOT NULL,
    department VARCHAR(255),
    position VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert default admin account
INSERT INTO users (email, password, role) VALUES ('Admin101', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');
