<?php
session_start();

class Auth {
    private $conn;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    public function login($email, $password) {
        $query = "SELECT id, email, password, role FROM users WHERE email = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$email]);
        
        if ($stmt->rowCount() > 0) {
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // For admin, check plain text password (Admin101)
            if ($user['role'] === 'admin' && $password === 'Admin101') {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];
                return true;
            }
            // For other users, check hashed password
            elseif (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];
                return true;
            }
        }
        return false;
    }
    
    public function register($email, $password, $role, $additional_data = []) {
        // Check if user already exists
        $check_query = "SELECT id FROM users WHERE email = ?";
        $check_stmt = $this->conn->prepare($check_query);
        $check_stmt->execute([$email]);
        
        if ($check_stmt->rowCount() > 0) {
            return false; // User already exists
        }
        
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $query = "INSERT INTO users (email, password, role) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        
        if ($stmt->execute([$email, $hashed_password, $role])) {
            $user_id = $this->conn->lastInsertId();
            
            // Insert additional data based on role
            if ($role === 'faculty' && !empty($additional_data)) {
                $faculty_query = "INSERT INTO faculty (user_id, full_name, department, position) VALUES (?, ?, ?, ?)";
                $faculty_stmt = $this->conn->prepare($faculty_query);
                $faculty_stmt->execute([
                    $user_id,
                    $additional_data['full_name'],
                    $additional_data['department'],
                    $additional_data['position']
                ]);
            }
            
            return true;
        }
        return false;
    }
    
    public function logout() {
        session_destroy();
        header("Location: index.php");
        exit();
    }
    
    public function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }
    
    public function getRole() {
        return $_SESSION['role'] ?? null;
    }
}
?>
