<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

$database = new Database();
$db = $database->getConnection();
$auth = new Auth($db);

$success_message = '';
$error_message = '';

if ($_POST) {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $role = $_POST['role'] ?? '';
    
    if ($password !== $confirm_password) {
        $error_message = 'Passwords do not match';
    } elseif (strlen($password) < 6) {
        $error_message = 'Password must be at least 6 characters long';
    } else {
        $additional_data = [];
        
        if ($role === 'faculty') {
            $additional_data = [
                'full_name' => $_POST['full_name'] ?? '',
                'department' => $_POST['department'] ?? '',
                'position' => $_POST['position'] ?? ''
            ];
        }
        
        if ($auth->register($email, $password, $role, $additional_data)) {
            $success_message = 'Account created successfully! You can now login.';
        } else {
            $error_message = 'Email already exists or registration failed';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create New Account - Student Profiling System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px 0;
        }
        .admission-container {
            max-width: 600px;
            margin: 0 auto;
        }
        .admission-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .admission-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem;
            text-align: center;
        }
        .admission-body {
            padding: 2rem;
        }
        .role-selection {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 25px;
        }
        .role-card {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
        }
        .role-card.active {
            border-color: #667eea;
            background: #f8f9ff;
        }
        .faculty-fields {
            display: none;
            background: #f8f9ff;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .form-control {
            border-radius: 8px;
            border: 2px solid #e9ecef;
            padding: 12px;
        }
        .btn-create {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 8px;
            padding: 12px;
            width: 100%;
            color: white;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="admission-container">
        <div class="admission-card">
            <div class="admission-header">
                <h2><i class="fas fa-user-plus"></i> Create New Account</h2>
                <p class="mb-0">Join our Student Profiling System</p>
            </div>
            <div class="admission-body">
                <?php if ($success_message): ?>
                    <div class="alert alert-success"><?php echo $success_message; ?></div>
                <?php endif; ?>
                
                <?php if ($error_message): ?>
                    <div class="alert alert-danger"><?php echo $error_message; ?></div>
                <?php endif; ?>
                
                <form method="POST" id="admissionForm">
                    <div class="role-selection">
                        <div class="role-card" data-role="faculty">
                            <i class="fas fa-chalkboard-teacher fa-2x text-primary mb-2"></i>
                            <h5>Faculty Account</h5>
                            <p class="small text-muted">For teachers and staff members</p>
                            <input type="radio" name="role" value="faculty" style="display: none;">
                        </div>
                        <div class="role-card" data-role="student">
                            <i class="fas fa-user-graduate fa-2x text-success mb-2"></i>
                            <h5>Student Account</h5>
                            <p class="small text-muted">For students and learners</p>
                            <input type="radio" name="role" value="student" style="display: none;">
                        </div>
                    </div>
                    
                    <div class="faculty-fields" id="facultyFields">
                        <h6 class="mb-3"><i class="fas fa-info-circle"></i> Faculty Information</h6>
                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <label for="full_name" class="form-label">Full Name</label>
                                <input type="text" class="form-control" id="full_name" name="full_name">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="department" class="form-label">Department</label>
                                <input type="text" class="form-control" id="department" name="department">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="position" class="form-label">Position</label>
                                <input type="text" class="form-control" id="position" name="position">
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="confirm_password" class="form-label">Confirm Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-create">
                        <i class="fas fa-user-plus"></i> Create Account
                    </button>
                </form>
                
                <div class="text-center mt-3">
                    <a href="index.php" class="text-decoration-none">
                        <i class="fas fa-arrow-left"></i> Back to Login
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.querySelectorAll('.role-card').forEach(card => {
            card.addEventListener('click', function() {
                // Remove active class from all cards
                document.querySelectorAll('.role-card').forEach(c => c.classList.remove('active'));
                
                // Add active class to clicked card
                this.classList.add('active');
                
                // Set the radio button value
                const role = this.dataset.role;
                this.querySelector('input[type="radio"]').checked = true;
                
                // Show/hide faculty fields
                const facultyFields = document.getElementById('facultyFields');
                if (role === 'faculty') {
                    facultyFields.style.display = 'block';
                    // Make faculty fields required
                    document.getElementById('full_name').required = true;
                    document.getElementById('department').required = true;
                    document.getElementById('position').required = true;
                } else {
                    facultyFields.style.display = 'none';
                    // Remove required attribute from faculty fields
                    document.getElementById('full_name').required = false;
                    document.getElementById('department').required = false;
                    document.getElementById('position').required = false;
                }
            });
        });
    </script>
</body>
</html>
